#include "opencv2/core.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/aruco.hpp"
#include "opencv2/calib3d.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <opencv2/core/hal/interface.h>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include "opencv2/gapi/imgproc.hpp"
#include <sstream>
#include <iostream>
#include <fstream>


const float calibrationSquareDimension = 0.03f; //meters
const float arucoSquareDimension =0.1016f;
const cv::Size chessboardDimension = cv::Size(6,8);

void createArucoMarkers(){
	cv::Mat outputMarker;

	cv::Ptr<cv::aruco::Dictionary> markerDictionary = cv::aruco::getPredefinedDictionary(cv::aruco::PREDEFINED_DICTIONARY_NAME::DICT_6X6_250);
for(int i = 0; i< 50;i++){
	cv::aruco::drawMarker(markerDictionary, i, 500, outputMarker, 1);
	std::ostringstream convert;
	std::string imageName = "aru/6X6Marker_";
	convert << imageName << i << ".jpg";
	cv::imwrite(convert.str(), outputMarker);
}

}

int startWebcamMonitoring(const cv::Mat& cameraMatrix, const cv::Mat& distanceCoefficients, float arucoSquareDimension){
	cv::Mat frame;
	cv::Mat frameCopy; //= cv::imread("ddd.jpg", cv::IMREAD_GRAYSCALE);
	
	std::vector<int> markerIds;
	std::vector<std::vector<cv::Point2f>> markerCorners, rejectedCandidates, rejected;
	cv::aruco::DetectorParameters parameters;
	cv::Ptr<cv::aruco::DetectorParameters> detectorParams = cv::aruco::DetectorParameters::create();
	cv::Ptr<cv::aruco::Dictionary> markerDictionary = cv::aruco::getPredefinedDictionary(cv::aruco::PREDEFINED_DICTIONARY_NAME::DICT_6X6_250);

	cv::VideoCapture vid(2);
	vid.set(cv::CAP_PROP_FRAME_WIDTH, 640);
	vid.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
	vid.set(cv::CAP_PROP_AUTOFOCUS, 0);
/* sirf
auto detector = cv::xfeatures2d::SiftFeatureDetector::create();
std::vector<cv::KeyPoint>keypoints;
detector->detect(frame,keypoints);
cv::Mat image_with_keypoints;
cv::drawKeypoints(frame,keypoints,image_with_keypoints);
auto extractor = cv::xfeatures2d::SiftDescriptorExtractor::create();
cv::Mat descriptors;
extractor->compute(frame,keypoints,descriptors);
*/

	if(!vid.isOpened())
	{
		return -1;

	}
	namedWindow("Webcam", cv::WINDOW_AUTOSIZE);

	std::vector<cv::Vec3d> rotationVectors, translationVectors;;

	while(true){
		if(!vid.read(frame))
	break;
	cv::cvtColor(frame,frameCopy,cv::COLOR_BGR2GRAY);
	cv::Ptr<cv::Feature2D> feature = cv::ORB::create();
	std::vector<cv::KeyPoint>keypoints;

	feature->detect(frameCopy, keypoints);

	cv::Mat desc;
	feature->compute(frameCopy,keypoints,desc);

	cv::Mat dst;
	cv::drawKeypoints(frameCopy, keypoints, dst, cv::Scalar(0,0,255), cv::DrawMatchesFlags::DEFAULT);

	cv::aruco::detectMarkers(dst,
		       	markerDictionary, markerCorners, markerIds, detectorParams, rejected);

	cv::aruco::estimatePoseSingleMarkers(markerCorners,
		       	arucoSquareDimension,
		       	cameraMatrix,
		       	distanceCoefficients, rotationVectors, translationVectors);

	if(markerIds.size()>0){
		cv::aruco::drawDetectedMarkers(dst, markerCorners, markerIds);

		for(int i=0;i<markerIds.size();i++){
			cv::aruco::drawAxis(dst, cameraMatrix, distanceCoefficients,
					rotationVectors[i],
					translationVectors[i], 0.1f);
		}

	}

//cv::Mat resu;
//cv::cvtColor(dst, resu ,cv::COLOR_GRAY2BGR);


	cv::imshow("Webcam", dst);
	if(cv::waitKey(30) >= 0) break;
	
	}
	return 1;
}

bool getChessboardList(std::string fileName, std::vector<std::string>& imagelist){
	
	imagelist.resize(0);
	cv::FileStorage fs(fileName, cv::FileStorage::READ);
	if( !fs.isOpened()) return false;

	cv::FileNode n = fs.getFirstTopLevelNode();
	cv::FileNodeIterator it = n.begin(), it_end = n.end();
	for( ; it != it_end; ++it )
	{
		imagelist.push_back((std::string)* it);
	}
	return true;
}


void cameraCalibration(std::vector<cv::Mat> calibrationImages, cv::Size boardSize, float squareEdgeLength, cv::Mat& cameraMatrix, cv::Mat& distanceCoefficients){
	/*
	std::vector<std::vector<cv::Point2f>> checkerboardImageSpacePoints;
	checkerboardImageSpacePoints.resize(num);
		
	cv::Mat gray;
	int i = 0;
	for(std::vector<cv::Mat>::iterator iter = calibrationImages.begin(); iter != calibrationImages.end(); iter++,i++ ){
		std::vector<cv::Point2f>& pointBuf = checkerboardImageSpacePoints[i];
		cv::cvtColor(*iter, gray, cv::COLOR_BGR2GRAY);
		bool found = findChessboardCorners(*iter, cv::Size(8,6), pointBuf, cv::CALIB_CB_ADAPTIVE_THRESH |cv::CALIB_CB_FAST_CHECK | cv::CALIB_CB_NORMALIZE_IMAGE);
		if(found){
			cv::TermCriteria criteria(cv::TermCriteria::EPS | cv::TermCriteria::MAX_ITER, 30, 0.001);
    	 	cv::cornerSubPix(gray, pointBuf, cv::Size(11,11), cv::Size(-1,-1),criteria);
			checkerboardImageSpacePoints.push_back(pointBuf);
		}	
	}
	std::vector<std::vector<cv::Point3f>> worldSpaceCornerPoints (1);
for(int k = 0; k < 2; k++){
	for(int i =0; i < boardSize.height; i++){
		for(int j = 0; j < boardSize.width; j++){
			worldSpaceCornerPoints[k].push_back(cv::Point3f(j*squareEdgeLength, i*squareEdgeLength, 0.0f));
		}
	}
}
//	std::cout << worldSpaceCornerPoints[0] << std::endl;

	worldSpaceCornerPoints.resize(checkerboardImageSpacePoints.size(), worldSpaceCornerPoints[0]);

	std::vector<cv::Mat> rVectors, tVectors;
	distanceCoefficients = cv::Mat::zeros(8,1,CV_64F);
	calibrateCamera(worldSpaceCornerPoints, checkerboardImageSpacePoints, boardSize, cameraMatrix, distanceCoefficients, rVectors, tVectors);
*/
	std::vector<std::string> imagelist;
	bool ok = getChessboardList("imagefile.xml", imagelist);

	int maxScale = 2;
	std::vector<std::vector<cv::Point2f>> imagePoints;
	std::vector<std::vector<cv::Point3f>> objectPoints;

	int nimages = (int)calibrationImages.size();
	std::cout << "the number of images = " << nimages << std::endl;

	imagePoints.resize(nimages);

	bool found;

	int i, j, k;

	cv::Mat img;
	cv::Size imageSize;
	for( i = 0; i < nimages; i++) {

		const std::string& filename = imagelist[i];
		img = cv::imread(filename, cv::IMREAD_GRAYSCALE);
		
		std::cout << "//////////////////" << std::endl;

		std::vector<cv::Point2f>& corners = imagePoints[i];
			
		for(int scale = 1; scale <= maxScale; scale++) {
			cv::Mat timg;
			if(scale == 1)	
				timg = img.clone();
			else
				cv::resize(img, timg, cv::Size(), scale, scale, cv::INTER_LINEAR_EXACT);//scale : 이미지 비율(fx, fy), cv::Size() : 이미지 사이즈를 설정하지 않음

				found = findChessboardCorners(timg, chessboardDimension, corners,
					cv::CALIB_CB_ADAPTIVE_THRESH | cv::CALIB_CB_NORMALIZE_IMAGE);
				
				if( found ) {
					if( scale < 1 )
					{
						cv::Mat cornersMat(corners);
						cornersMat *= 1./scale;
					}
					break;
				}
		}				
			cv::Mat cornerImg;
			cornerImg = img.clone();
			drawChessboardCorners(cornerImg, chessboardDimension, corners, found);				
			double sf = 640./std::max(img.rows, img.cols); //비율 조정
//			cv::imshow("corners", cornerImg);
//			cv::waitKey();
		
			if(!found) break;
			
			cv::cornerSubPix(img, corners, cv::Size(11, 11), cv::Size(-1, -1),
			cv::TermCriteria(cv::TermCriteria::COUNT+cv::TermCriteria::EPS, 30, 0.01));
	}
	imageSize = img.size();

	imagePoints.resize(nimages);
	objectPoints.resize(nimages);

	for(i = 0; i < nimages; i++)
	{
		for(j = 0; j <chessboardDimension.height; j++)
			for(k = 0; k < chessboardDimension.width; k++)
				objectPoints[i].push_back(cv::Point3f(k*calibrationSquareDimension
				, j*calibrationSquareDimension, 0)); //chessboard size 를 이용하여 world 좌표 push
	}
	cv::Mat RVec, TVec;
	std::cout << "Running calibration!" << std::endl << "====================================" << std::endl;
	cameraMatrix = initCameraMatrix2D(objectPoints, imagePoints, imageSize, 0); //z=0 일 때만 적용가능	
	std::cout << "camera matrix" << std::endl << cameraMatrix << std::endl;

	cv::Mat stdDevlationsIntrinsics, stdDevlationsExtrinsics, perViewErrors;
	
	double rms = calibrateCamera(objectPoints, imagePoints, imageSize, cameraMatrix, distanceCoefficients, 
		         	     RVec, TVec, stdDevlationsIntrinsics, stdDevlationsExtrinsics, perViewErrors, 0, 
				     	 cv::TermCriteria(cv::TermCriteria::COUNT+cv::TermCriteria::EPS, 30, DBL_EPSILON));
	
	cv::Mat chessboard, result;

	/*for(i = 0; i < nimages; i++)
	{	
		const std::string& filename = imagelist[i];
		chessboard = cv::imread(filename, cv::IMREAD_GRAYSCALE);
		
	 	cv::undistort(chessboard, result, cameraMatrix, distanceCoefficients, cv::noArray());
		cv::imshow("chessboard undistort", result);
		cv::waitKey(0);
	}
*/
	//saveInstrinsicParam("intrinsics.yml", cameraMatrix, distanceCoefficients);

	std::cout << "\ndistorian_coefficients" << std::endl << distanceCoefficients << std::endl;

	//camera coordinate -> world coordinate
//	std::cout << "R vector from Calibration" << std::endl << RVec << std::endl;
	std::cout << "T vector from Calibration" << std::endl << TVec << std::endl;
	//saveExtParamCalib("extrinsics_cali.yml", RVec, TVec);

	std::cout << "\ncompute extrinsics parameter from solvePnP" << std::endl;
	
	cv::Mat R, Rmatrix, T;
	for(i = 0; i < nimages; i++) 
	{ 
		cv::solvePnP(objectPoints[i], imagePoints[i], cameraMatrix, distanceCoefficients, R, T, false);
		cv::Rodrigues(R, Rmatrix);
		
		cv::Mat R_inv = Rmatrix.inv();
		cv::Mat P = -R_inv * T;
		float* position = (float*) P.data;
		std::cout << "camera position = " << position[0] << ", " << position[1] << ", " << position[2] << std::endl;

		std::cout << "R matrix from solvePnP" << std::endl << Rmatrix << std::endl;
//		std::cout << "T vector from solvePnP" << std::endl << TVec << std::endl;

	//	saveExtParamSolvePnP("extrinsics_solvePnP.yml", Rmatrix, T);

	}

}


bool saveCameraCalibration(std::string name, cv::Mat cameraMatrix, cv::Mat distanceCoefficients){
	
    cv::FileStorage fs(name, cv::FileStorage::WRITE);

	if(!fs.isOpened()) return false;
   	fs << "camera_matrix" << cameraMatrix;
	fs << "distortion_coefficients" << distanceCoefficients;
	fs.release();
	return true;
	
	
	}

bool loadCameraCalibration(std::string name, cv::Mat& cameraMatrix, cv::Mat& distanceCoefficients){
    cv::FileStorage fs3(name, cv::FileStorage::READ);

	if(!fs3.isOpened()) return false;
	fs3["camera_matrix"] >> cameraMatrix; 
	fs3["distortion_coefficients"] >> distanceCoefficients;
	fs3.release();
	return true;
}

void cameraCalibrationProcess(cv::Mat& cameraMatrix, cv::Mat& distanceCoefficients){
	
	cv::Mat frame, drawToFrame;
	cv::Mat img, readImg, gray;
	std::vector<cv::Mat> savedImages;
	std::string path("../chessboard/*.jpg");
	std::vector<std::string> str;
	std::vector<std::vector<cv::Point2f>> markerCorners, rejectedCandidates;

	cv::VideoCapture vid(2);
	vid.set(cv::CAP_PROP_FRAME_WIDTH, 640);
	vid.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

	if(!vid.isOpened()){
		return;
	}
	
	int c = 0, index = 0;
	char savefile[100], buf[256];

	cv::FileStorage fs2("chessboard.xml", cv::FileStorage::WRITE);

	namedWindow("Webcam", cv::WINDOW_AUTOSIZE);

	while(true){
		if(!vid.read(frame)) break;

		std::vector<cv::Vec2f> foundPoints;
		bool found = false;

		found = findChessboardCorners(frame, chessboardDimension, foundPoints, cv::CALIB_CB_ADAPTIVE_THRESH  | cv::CALIB_CB_FAST_CHECK | cv::CALIB_CB_NORMALIZE_IMAGE);
		frame.copyTo(drawToFrame);		
		if(found) {
			drawChessboardCorners(drawToFrame, chessboardDimension, foundPoints, found);
			cv::imshow("Webcam", drawToFrame);
		}else cv::imshow("Webcam", frame);
				
		int i = cv::waitKey(1);

		switch(i){
			case 13:
				std::cout << "///////////////////" << std::endl;
				cv::glob(path,str,false);
				if(str.size()>=15){
					for(int cnt=0;cnt<str.size();cnt++){
						savedImages.push_back(cv::imread(str[cnt]));
					}
				std::cout << "///////////////////" << std::endl;
				cameraCalibration(
						savedImages,
						chessboardDimension,
					    calibrationSquareDimension,
						cameraMatrix, 
						distanceCoefficients);

	      		saveCameraCalibration("cameracalibration.xml", cameraMatrix, distanceCoefficients);
				}
				break;
			case ' ':
				if(found){
				sprintf(savefile, "../chessboard/img%d.jpg", c++);
				printf("%s", savefile);
				cv::imwrite(savefile, frame);
				fs2 << "imagelist" << savefile;
				}
				break;
			
			case 27: 
				std::cout << "exit"<<std::endl;
				return;
				break;
		}
	}
	}


int main(int argv, char** argc){
	cv::Mat cameraMatrix = cv::Mat::eye(3,3,CV_64F);
	cv::Mat distanceCoefficients;
	
	//createArucoMarkers();
	//cameraCalibrationProcess(cameraMatrix,distanceCoefficients);
	loadCameraCalibration("cameracalibration.xml", cameraMatrix, distanceCoefficients);
	startWebcamMonitoring(cameraMatrix, distanceCoefficients, arucoSquareDimension);
	}
